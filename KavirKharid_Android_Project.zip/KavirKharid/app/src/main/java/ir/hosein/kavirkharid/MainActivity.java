package ir.hosein.kavirkharid;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONTokener;
import org.json.JSONObject;

import java.net.URI;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    // The official sales/customer portal. The website may redirect to its own login system.
    private static final String SALES_URL = "https://customer.kavirtire.ir/";
    private static final String OFFICIAL_SALES_URL = "https://kavirtire.ir/esale";
    private static final String PREFS = "kavir_kharid_config";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private EditText targetInput, quantityInput;
    private Spinner intervalSpinner;
    private CheckBox scheduleCheck;
    private Button timeButton, startButton, stopButton, openSiteButton;
    private TextView statusText, statusDot;
    private SharedPreferences prefs;

    private boolean botRunning = false;
    private boolean scheduledStartPending = false;
    private int scheduledHour = 8;
    private int scheduledMinute = 0;
    private int intervalSeconds = 8;
    private Runnable scheduledStart;
    private Runnable statusPoller;
    private String lastNativeStatus = "";
    private boolean officialFallbackTried = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(16, 23, 32));
        getWindow().setNavigationBarColor(Color.rgb(16, 23, 32));
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        bindViews();
        setupIntervalSpinner();
        restoreConfig();
        setupWebView();
        setupActions();

        if (savedInstanceState == null) {
            webView.loadUrl(SALES_URL);
        }
        setStatus("آماده؛ وارد سامانه فروش شو", false);
    }

    private void bindViews() {
        webView = findViewById(R.id.siteWebView);
        targetInput = findViewById(R.id.targetInput);
        quantityInput = findViewById(R.id.quantityInput);
        intervalSpinner = findViewById(R.id.intervalSpinner);
        scheduleCheck = findViewById(R.id.scheduleCheck);
        timeButton = findViewById(R.id.timeButton);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        openSiteButton = findViewById(R.id.openSiteButton);
        statusText = findViewById(R.id.statusText);
        statusDot = findViewById(R.id.statusDot);
    }

    private void setupIntervalSpinner() {
        String[] choices = {"۵ ثانیه", "۸ ثانیه", "۱۲ ثانیه", "۲۰ ثانیه"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, choices);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        intervalSpinner.setAdapter(adapter);
        intervalSpinner.setSelection(1);
        intervalSpinner.setPopupBackgroundResource(R.color.surface_alt);
    }

    private void restoreConfig() {
        targetInput.setText(prefs.getString("target", ""));
        quantityInput.setText(String.valueOf(prefs.getInt("quantity", 2)));
        scheduledHour = prefs.getInt("hour", 8);
        scheduledMinute = prefs.getInt("minute", 0);
        scheduleCheck.setChecked(prefs.getBoolean("scheduled", false));
        int spinnerIndex = prefs.getInt("intervalIndex", 1);
        intervalSpinner.setSelection(Math.min(Math.max(spinnerIndex, 0), 3));
        updateTimeButton();
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if (scheme.equals("http") || scheme.equals("https")) {
                    return false; // Keep HTTPS sales and payment pages inside the app.
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "این پیوند در گوشی قابل بازکردن نیست.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (botRunning) {
                    if (isKavirDomain(url)) {
                        injectBotScript();
                    } else if (isPaymentUrl(url)) {
                        // Stop before a payment gateway; the user must choose/confirm payment manually.
                        stopBotOnly("به صفحه درگاه رسیدی؛ پرداخت را خودت بررسی و تأیید کن", true);
                    } else {
                        // Login/identity pages may be on a different host; wait for the user to finish.
                        setStatus("صفحه ورود/احراز هویت باز است؛ تکمیلش کن تا به سامانه برگردی", false);
                    }
                } else if (isKavirDomain(url)) {
                    setStatus("سامانه باز است؛ سایز لاستیک را وارد کن", false);
                } else {
                    setStatus("صفحه بیرونی باز شد", false);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    String failed = request.getUrl() == null ? "" : request.getUrl().toString();
                    if (!officialFallbackTried && failed.contains("customer.kavirtire.ir")) {
                        officialFallbackTried = true;
                        setStatus("مسیر اول پاسخ نداد؛ مسیر رسمی جایگزین را امتحان می‌کنم…", true);
                        view.loadUrl(OFFICIAL_SALES_URL);
                    } else {
                        setStatus("بارگذاری سامانه ناموفق بود؛ اینترنت را بررسی یا دوباره تلاش کن", true);
                    }
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                super.onReceivedHttpError(view, request, response);
                if (request.isForMainFrame() && response != null && response.getStatusCode() >= 400) {
                    String failed = request.getUrl() == null ? "" : request.getUrl().toString();
                    if (!officialFallbackTried && failed.contains("customer.kavirtire.ir")) {
                        officialFallbackTried = true;
                        setStatus("مسیر اول پاسخ نداد؛ مسیر رسمی جایگزین را امتحان می‌کنم…", true);
                        view.loadUrl(OFFICIAL_SALES_URL);
                    }
                }
            }
        });
    }

    private void setupActions() {
        timeButton.setOnClickListener(v -> {
            TimePickerDialog dialog = new TimePickerDialog(this, (picker, hour, minute) -> {
                scheduledHour = hour;
                scheduledMinute = minute;
                updateTimeButton();
                prefs.edit().putInt("hour", hour).putInt("minute", minute).apply();
            }, scheduledHour, scheduledMinute, true);
            dialog.setTitle("زمان شروع ربات");
            dialog.show();
        });

        startButton.setOnClickListener(v -> startRequested());
        stopButton.setOnClickListener(v -> stopAll());
        openSiteButton.setOnClickListener(v -> {
            officialFallbackTried = false;
            String current = webView.getUrl();
            if (current == null || !isKavirDomain(current)) {
                webView.loadUrl(SALES_URL);
            } else {
                webView.reload();
            }
            setStatus("در حال بازکردن سامانه فروش رسمی…", false);
        });
        openSiteButton.setOnLongClickListener(v -> {
            officialFallbackTried = true;
            webView.loadUrl(OFFICIAL_SALES_URL);
            setStatus("در حال امتحان مسیر جایگزین فروش رسمی…", false);
            return true;
        });
    }

    private void updateTimeButton() {
        timeButton.setText(String.format(Locale.US, "%02d:%02d", scheduledHour, scheduledMinute));
    }

    private void saveConfig(String target, int quantity, int spinnerIndex) {
        prefs.edit()
                .putString("target", target)
                .putInt("quantity", quantity)
                .putInt("intervalIndex", spinnerIndex)
                .putInt("hour", scheduledHour)
                .putInt("minute", scheduledMinute)
                .putBoolean("scheduled", scheduleCheck.isChecked())
                .apply();
    }

    private void startRequested() {
        String target = targetInput.getText().toString().trim();
        if (target.isEmpty()) {
            targetInput.setError("سایز یا کد دقیق لاستیک را وارد کن");
            targetInput.requestFocus();
            return;
        }
        int quantity;
        try {
            quantity = Integer.parseInt(quantityInput.getText().toString().trim());
        } catch (Exception e) {
            quantity = 2;
        }
        if (quantity < 1 || quantity > 4) {
            quantityInput.setError("تعداد باید بین ۱ تا ۴ حلقه باشد");
            return;
        }
        int index = intervalSpinner.getSelectedItemPosition();
        int[] intervals = {5, 8, 12, 20};
        intervalSeconds = intervals[Math.min(Math.max(index, 0), intervals.length - 1)];
        saveConfig(target, quantity, index);
        hideKeyboard();

        if (scheduleCheck.isChecked()) {
            long delay = millisUntilScheduledTime();
            if (delay > 0) {
                cancelScheduledStart();
                scheduledStartPending = true;
                setStatus("شروع زمان‌دار برای " + String.format(Locale.US, "%02d:%02d", scheduledHour, scheduledMinute) + " تنظیم شد", false);
                scheduledStart = this::beginBot;
                handler.postDelayed(scheduledStart, delay);
                Toast.makeText(this, "شروع زمان‌دار ثبت شد", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        beginBot();
    }

    private long millisUntilScheduledTime() {
        Calendar now = Calendar.getInstance();
        Calendar target = (Calendar) now.clone();
        target.set(Calendar.HOUR_OF_DAY, scheduledHour);
        target.set(Calendar.MINUTE, scheduledMinute);
        target.set(Calendar.SECOND, 0);
        target.set(Calendar.MILLISECOND, 0);
        if (!target.after(now)) target.add(Calendar.DAY_OF_YEAR, 1);
        return Math.max(0L, target.getTimeInMillis() - now.getTimeInMillis());
    }

    private void beginBot() {
        scheduledStartPending = false;
        scheduledStart = null;
        String target = targetInput.getText().toString().trim();
        if (target.isEmpty()) {
            setStatus("سایز لاستیک خالی است؛ تنظیمات را کامل کن", true);
            return;
        }
        botRunning = true;
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        lastNativeStatus = "";
        setStatus("ربات فعال شد؛ ورود یا کد امنیتی را خودت تکمیل کن", false);
        Toast.makeText(this, "ربات روشن شد؛ خرید نهایی خودکار انجام نمی‌شود", Toast.LENGTH_LONG).show();
        String currentUrl = webView.getUrl();
        if (currentUrl == null || !isKavirDomain(currentUrl)) webView.loadUrl(SALES_URL);
        else injectBotScript();
        startStatusPoller();
    }

    private void stopAll() {
        cancelScheduledStart();
        stopBotOnly("ربات متوقف شد", false);
        Toast.makeText(this, "ربات متوقف شد", Toast.LENGTH_SHORT).show();
    }

    private void cancelScheduledStart() {
        if (scheduledStart != null) {
            handler.removeCallbacks(scheduledStart);
            scheduledStart = null;
        }
        scheduledStartPending = false;
    }

    private void stopBotOnly(String message, boolean warning) {
        botRunning = false;
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (webView != null) {
            webView.evaluateJavascript("window.__KAVIRBOT_ENABLED=false;if(window.__KAVIRBOT_TIMER){clearInterval(window.__KAVIRBOT_TIMER);}", null);
        }
        if (statusPoller != null) handler.removeCallbacks(statusPoller);
        statusPoller = null;
        setStatus(message, warning);
    }

    private void startStatusPoller() {
        if (statusPoller != null) handler.removeCallbacks(statusPoller);
        statusPoller = new Runnable() {
            @Override public void run() {
                if (!botRunning || webView == null) return;
                webView.evaluateJavascript("JSON.stringify(window.__KAVIRBOT_STATUS || '')", value -> {
                    if (!botRunning) return;
                    try {
                        Object decoded = new JSONTokener(value).nextValue();
                        String status = decoded == null ? "" : decoded.toString();
                        if (!status.isEmpty() && !status.equals(lastNativeStatus)) {
                            lastNativeStatus = status;
                            setStatus(status, status.startsWith("خطا") || status.startsWith("توقف"));
                            if (status.contains("صفحه انتخاب پرداخت آماده است") || status.contains("درگاه پرداخت باز شد")) {
                                stopBotOnly(status, false);
                                Toast.makeText(MainActivity.this, "به مرحله پرداخت رسیدی؛ پرداخت را خودت تأیید کن", Toast.LENGTH_LONG).show();
                            }
                        }
                    } catch (Exception ignored) { }
                });
                handler.postDelayed(this, 1400);
            }
        };
        handler.post(statusPoller);
    }

    private void injectBotScript() {
        if (!botRunning) return;
        String target = targetInput.getText().toString().trim();
        int qty;
        try { qty = Integer.parseInt(quantityInput.getText().toString().trim()); }
        catch (Exception e) { qty = 2; }
        qty = Math.min(Math.max(qty, 1), 4);
        int[] intervals = {5, 8, 12, 20};
        intervalSeconds = intervals[Math.min(Math.max(intervalSpinner.getSelectedItemPosition(), 0), intervals.length - 1)];
        String qJs = JSONObject.quote(target);
        String qtyJs = Integer.toString(qty);
        String intervalJs = Integer.toString(intervalSeconds * 1000);

        String script = "(function(){try{" +
                "window.__KAVIRBOT_ENABLED=true;" +
                "window.__KAVIRBOT_CONFIG={q:" + qJs + ",qty:" + qtyJs + ",intervalMs:" + intervalJs + "};" +
                "window.__KAVIRBOT_STATUS=window.__KAVIRBOT_STATUS||'ربات فعال است؛ در حال بررسی سامانه';" +
                "if(window.__KAVIRBOT_TIMER){clearInterval(window.__KAVIRBOT_TIMER);}" +
                "const cfg=window.__KAVIRBOT_CONFIG;" +
                "const norm=s=>(s||'').toString().toLowerCase().replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[\\u200c\\s]+/g,'').replace(/ي/g,'ی').replace(/ك/g,'ک');" +
                "const compact=s=>norm(s).replace(/[^a-z0-9\\u0600-\\u06ff]/g,'');" +
                "const setStatus=s=>{window.__KAVIRBOT_STATUS=s;};" +
                "const body=()=>document.body?document.body.innerText||'':'';" +
                "const authOrCaptcha=()=>{const t=norm(body());const hasPwd=!!document.querySelector('input[type=password]');const hasPhone=!!document.querySelector('input[type=tel],input[name*=phone i],input[name*=mobile i]');return ((t.includes('کدامنیتی')||t.includes('عبارتتصویر')||t.includes('captcha')||t.includes('کدیکبارمصرف')||t.includes('کدپیامکی')||t.includes('کدملی')||hasPwd||hasPhone)&&(/ورود|ثبتنام|تایید|احراز|captcha|کدملی|رمز|رمزعبور/.test(t)||hasPwd||hasPhone));};" +
                "const isGateway=()=>{const t=norm(body());return /انتخابدرگاه|درگاهپرداخت|پرداختاینترنتی|شمارهکارت|cvv2|رمزپویا|bankgateway/.test(t)||/payment|gateway/i.test(location.href);};" +
                "const isOut=t=>/ناموجود|اتمامموجودی|درانبارموجودنیست|موجودنیست|اتمامموجودی|عدمموجودی/.test(norm(t));" +
                "const hasQuery=t=>{const n=norm(t),q=norm(cfg.q);return q.length>0&&(n.includes(q)||compact(t).includes(compact(cfg.q)));};" +
                "const safeAddLabel=t=>/افزودنبهسبد|افزودنبهسبدخرید|اضافهبهسبد|افزودنبهکارت|افزودنسبد|خرید/.test(norm(t));const explicitAddLabel=t=>/افزودنبهسبد|افزودنبهسبدخرید|اضافهبهسبد|افزودنبهکارت|افزودنسبد/.test(norm(t));" +
                "const paymentLabel=t=>{const n=norm(t);return !/ثبتسفارش|ثبتنهایی|پرداختنهایی|پرداختقطعی/.test(n)&&/تکمیلخرید|ادامهبهپرداخت|ادامهفرایندخرید|ادامهفرآیندخرید|انتخابدرگاه|رفتنبهسبدخرید|مشاهدهسبدخرید|ادامه/.test(n);};" +
                "const visible=el=>!!(el&&el.getBoundingClientRect().width&&el.getBoundingClientRect().height&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none');" +
                "const clickEl=el=>{if(!el)return false;try{el.scrollIntoView({block:'center',behavior:'instant'});}catch(e){};el.click();return true;};" +
                "const qKey='kavirbot_added_'+compact(cfg.q);const flowKey='kavirbot_flow_'+location.pathname;const searchKey='kavirbot_search_'+compact(cfg.q)+'_'+location.pathname;const selectSubmitKey='kavirbot_selectsubmit_'+compact(cfg.q)+'_'+location.pathname;" +
                "const selectionUi=()=>Array.from(document.querySelectorAll('select,input[type=search],input[type=text],input:not([type])')).some(el=>visible(el)&&/سایز|تایر|خودرو|ماشین|محصول|انتخاب|size|tire|product|vehicle|car/.test(norm((el.placeholder||'')+' '+(el.name||'')+' '+(el.id||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||''))));" +
                "function scan(){try{" +
                "if(!document.body){setStatus('در حال بارگذاری سامانه…');return;}" +
                "if(isGateway()){setStatus('درگاه پرداخت باز شد؛ پرداخت را خودت تأیید کن');return;}" +
                "if(authOrCaptcha()){setStatus('ورود یا کد امنیتی لازم است؛ خودت وارد کن، ربات منتظر می‌ماند');return;}" +
                "const added=sessionStorage.getItem(qKey)==='1';" +
                "if(added){const all=Array.from(document.querySelectorAll('button,a,input[type=button],input[type=submit]')).filter(visible);const next=all.find(el=>paymentLabel(el.innerText||el.value||el.getAttribute('aria-label')||el.title||''));if(next){setStatus('در حال رفتن به مرحله انتخاب پرداخت…');clickEl(next);return;}setStatus('محصول به سبد اضافه شد؛ در حال آماده‌سازی سبد خرید');return;}" +
                "const allControls=Array.from(document.querySelectorAll('button,a,input[type=button],input[type=submit]')).filter(visible);const startFlow=allControls.find(el=>/شروعفرایندخرید|شروعخرید/.test(norm(el.innerText||el.value||el.getAttribute('aria-label')||el.title||'')));if(startFlow&&sessionStorage.getItem(flowKey)!=='1'){sessionStorage.setItem(flowKey,'1');setStatus('در حال ورود به فرایند خرید…');clickEl(startFlow);return;}" +
                "const selects=Array.from(document.querySelectorAll('select')).filter(visible);for(const sel of selects){const opt=Array.from(sel.options||[]).find(o=>hasQuery(o.textContent||'')||compact(o.value)===compact(cfg.q));if(opt){if(sel.value!==opt.value){sel.value=opt.value;sel.dispatchEvent(new Event('input',{bubbles:true}));sel.dispatchEvent(new Event('change',{bubbles:true}));setStatus('سایز هدف انتخاب شد؛ در حال بارگذاری گزینه‌ها…');return;}const submit=allControls.find(el=>/جستجو|نمایشتایر|نمایشمحصول|ادامه|تایید|تأیید|اعمال/.test(norm(el.innerText||el.value||el.getAttribute('aria-label')||el.title||'')));if(submit&&sessionStorage.getItem(selectSubmitKey)!=='1'){sessionStorage.setItem(selectSubmitKey,'1');setStatus('سایز انتخاب شد؛ در حال جست‌وجوی محصول…');clickEl(submit);return;}}}" +
                "if(sessionStorage.getItem(searchKey)!=='1'){const fields=Array.from(document.querySelectorAll('input[type=search],input[type=text],input:not([type])')).filter(visible);const field=fields.find(el=>/جستجو|سایز|تایر|محصول|search|size|tire|product/.test(norm((el.placeholder||'')+' '+(el.name||'')+' '+(el.id||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||''))));if(field&&!hasQuery(field.value||'')){field.focus();const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;setter.call(field,cfg.q);field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));sessionStorage.setItem(searchKey,'1');const form=field.form;const submit=form?form.querySelector('button[type=submit],input[type=submit],button'):null;if(submit){setStatus('در حال جست‌وجوی سایز هدف…');clickEl(submit);return;}if(form&&form.requestSubmit){setStatus('در حال جست‌وجوی سایز هدف…');form.requestSubmit();return;}}}" +
                "const selectors='article,li,tr,[class*=product i],[class*=card i],[class*=item i],[data-product]';" +
                "const candidates=Array.from(document.querySelectorAll(selectors)).filter(visible).filter(el=>hasQuery(el.innerText||''));" +
                "candidates.sort((a,b)=>(a.innerText||'').length-(b.innerText||'').length);" +
                "let chosen=null,add=null;" +
                "for(const el of candidates.slice(0,80)){const text=el.innerText||'';if(isOut(text))continue;const controls=Array.from(el.querySelectorAll('button,a,input[type=button],input[type=submit]')).filter(visible);const button=controls.find(b=>{const t=b.innerText||b.value||b.getAttribute('aria-label')||b.title||'';return safeAddLabel(t)&&!isOut(t)&&!b.disabled;});if(button){chosen=el;add=button;break;}}" +
                "if(chosen&&add){const qs=Array.from(chosen.querySelectorAll('input[type=number],input[name*=qty i],input[name*=quantity i],input[class*=quantity i]')).filter(visible);if(qs.length){const inp=qs[0];const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;setter.call(inp,String(cfg.qty));inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));}sessionStorage.setItem(qKey,'1');setStatus('محصول منطبق پیدا شد؛ در حال افزودن '+cfg.qty+' حلقه به سبد');if(qs.length){clickEl(add);}else if(explicitAddLabel(add.innerText||add.value||add.getAttribute('aria-label')||add.title||'')){for(let i=0;i<cfg.qty;i++){clickEl(add);}}else{setStatus('دکمه خرید پیدا شد؛ وارد سبد شو و تعداد حلقه‌ها را بررسی کن');clickEl(add);}return;}" +
                "const pageText=body();" +
                "if(hasQuery(pageText)&&!isOut(pageText)){setStatus('سایز هدف در صفحه دیده شد؛ کنترل‌های خرید شناسایی نشدند، صفحه را بررسی کن');}else{setStatus('موجودی پیدا نشد؛ بررسی دوباره در '+Math.round(cfg.intervalMs/1000)+' ثانیه');}" +
                "const host=location.hostname.toLowerCase();const kavir=host==='kavirtire.ir'||host.endsWith('.kavirtire.ir');" +
                "if(selectionUi()){setStatus('در مرحله انتخاب خودرو/سایز هستی؛ گزینه‌های لازم را تکمیل کن، ربات منتظر می‌ماند');return;}" +
                "if(kavir&&!added&&!authOrCaptcha()&&!isGateway()&&!window.__KAVIRBOT_RELOAD_PENDING){window.__KAVIRBOT_RELOAD_PENDING=true;setTimeout(()=>{try{if(window.__KAVIRBOT_ENABLED!==false&&!authOrCaptcha()&&!isGateway()&&!selectionUi()&&sessionStorage.getItem(qKey)!=='1')location.reload();else window.__KAVIRBOT_RELOAD_PENDING=false;}catch(e){window.__KAVIRBOT_RELOAD_PENDING=false;}},cfg.intervalMs);}" +
                "}catch(e){setStatus('خطا هنگام بررسی صفحه؛ سامانه را دستی بررسی کن');}}" +
                "scan();window.__KAVIRBOT_TIMER=setInterval(scan,Math.max(cfg.intervalMs,5000));" +
                "}catch(e){window.__KAVIRBOT_STATUS='خطا در راه‌اندازی دستیار';}})();";
        webView.evaluateJavascript(script, null);
    }

    private boolean isPaymentUrl(String url) {
        if (url == null) return false;
        String value = url.toLowerCase(Locale.ROOT);
        return value.contains("payment") || value.contains("gateway") || value.contains("shaparak") ||
                value.contains("behpardakht") || value.contains("sadad") || value.contains("pec.ir") ||
                value.contains("bpm.") || value.contains("sep.ir") || value.contains("bankpayment");
    }

    private boolean isKavirDomain(String url) {
        try {
            String host = new URI(url).getHost();
            return host != null && (host.equalsIgnoreCase("kavirtire.ir") || host.toLowerCase(Locale.ROOT).endsWith(".kavirtire.ir"));
        } catch (Exception e) {
            return false;
        }
    }

    private void setStatus(String message, boolean warning) {
        statusText.setText(message);
        statusDot.setTextColor(warning ? getResources().getColor(R.color.danger) : getResources().getColor(R.color.success));
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(targetInput.getWindowToken(), 0);
            if (imm != null) imm.hideSoftInputFromWindow(quantityInput.getWindowToken(), 0);
        } catch (Exception ignored) { }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        cancelScheduledStart();
        if (statusPoller != null) handler.removeCallbacks(statusPoller);
        if (webView != null) {
            webView.stopLoading();
            webView.removeAllViews();
            webView.destroy();
        }
        super.onDestroy();
    }
}
